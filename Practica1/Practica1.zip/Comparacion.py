a = 7
b = 5
if( a<b ):
    print("A es menor que B")
else:
    print("B es menor que A")
