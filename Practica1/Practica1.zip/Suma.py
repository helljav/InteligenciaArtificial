variable1 = 5
variable2 = 6
suma = variable1 + variable2
print("La suma de ",variable1,"+",variable2,"=",suma)
