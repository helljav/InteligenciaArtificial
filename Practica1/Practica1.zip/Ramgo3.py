#!/usr/bin/python3

#1º forma
print("Forma 1")
#Crea un arreglo del 1 al 10 y los pone de mayor a menor
rango = list(range(10,0,-1)) 
print(rango)


#2º forma
print("Forma 2")
#Crea un arreglo del 1 al 10
rango = list(range(1,11))
#Saca el reverso de un arreglo
rango.reverse()
print(rango)
