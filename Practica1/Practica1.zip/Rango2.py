#!/usr/bin/python3

#Se crea un arreglo conformado del 0 al 9
rango = list( range(10) )
print(rango)
