#!/usr/bin/python3
#1º forma
print("Forma 1")
for i in range(1,101):
    if( (i%2)==0): 
        print(i)
print("")


#2º forma
print("Forma 2")
for i in range(2,101,2): 
    print(i)
