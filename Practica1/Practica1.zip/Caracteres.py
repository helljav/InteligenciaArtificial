#!/usr/bin/python3
for i in "Hola mundo":
    print(i)
