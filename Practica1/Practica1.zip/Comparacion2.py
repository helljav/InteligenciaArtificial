a = 35
if(a>=1 and a<=10):
    print("Esta entre 1 y 10")
elif(a>=11 and a<=20):
    print("Esta entre 11 y 20")
elif(a>=21 and a<=30):
    print("Esta entre 21 y 30")
else:
    print("No esta en ese rango")
