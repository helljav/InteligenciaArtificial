#!/usr/bin/python3
rango1 = list(range(0,11))
rango2 = list(range(15,21))

print("Primera lista",rango1)
print("")
print("Segunda lista",rango2)
print("")

#Se crea una lista final los elementos de la primera lista y despues #lo de la segunda
final = rango1 + rango2
print("Concatenacion",final)
