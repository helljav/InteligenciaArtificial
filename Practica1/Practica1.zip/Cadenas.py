#!/usr/bin/python3
cadena1 = input("Dame la primera cadena: ")
cadena2 = input("Dame la segunda cadena: ")
#Toma los dos primeros  elementos de la cadena2 y los concatena con la #primera excepto los primeros dos

#Toma los dos primeros  elementos de la cadena1 y los concatena con la #segunda excepto los primeros dos

print( cadena2[:2] + cadena1[2:] + " " + cadena1[:2] + cadena2[2:] )
