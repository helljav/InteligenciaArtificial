#!/usr/bin/python3

#1º forma
print("Forma 1")
rango = list(range(10,0,-1)) 
print(rango)
#2º forma
print("Forma 2")
rango = list(range(1,11))
rango.reverse()
print(rango)
